import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SettingsProvider with ChangeNotifier {
  final _storage = FlutterSecureStorage();
  String _endpoint = '';
  String _accessKey = '';
  String _secretKey = '';
  String _region = '';

  String get endpoint => _endpoint;
  String get accessKey => _accessKey;
  String get secretKey => _secretKey;
  String get region => _region;

  SettingsProvider() {
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    _endpoint = await _storage.read(key: 'endpoint') ?? '';
    _accessKey = await _storage.read(key: 'accessKey') ?? '';
    _secretKey = await _storage.read(key: 'secretKey') ?? '';
    _region = await _storage.read(key: 'region') ?? '';
    notifyListeners();
  }

  Future<void> saveSettings(
    String endpoint,
    String accessKey,
    String secretKey,
    String region,
  ) async {
    await _storage.write(key: 'endpoint', value: endpoint);
    await _storage.write(key: 'accessKey', value: accessKey);
    await _storage.write(key: 'secretKey', value: secretKey);
    await _storage.write(key: 'region', value: region);
    _endpoint = endpoint;
    _accessKey = accessKey;
    _secretKey = secretKey;
    _region = region;
    notifyListeners();
  }
}
