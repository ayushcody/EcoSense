import 'package:flutter/material.dart';
import '../models/sensor_model.dart';

class SensorProvider with ChangeNotifier {
  final List<SensorModel> _sensors = [
    SensorModel(
      id: 'temperature',
      name: 'Temperature',
      type: 'temperature',
      unit: '°C',
      icon: Icons.thermostat,
    ),
    SensorModel(
      id: 'humidity',
      name: 'Humidity',
      type: 'humidity',
      unit: '%',
      icon: Icons.water_drop,
    ),
    SensorModel(
      id: 'air_quality',
      name: 'Air Quality',
      type: 'air_quality',
      unit: 'AQI',
      icon: Icons.air,
    ),
    SensorModel(
      id: 'ph',
      name: 'Water pH',
      type: 'ph',
      unit: 'pH',
      icon: Icons.science,
    ),
    SensorModel(
      id: 'gas',
      name: 'Gas Sensor',
      type: 'gas',
      unit: 'ppm',
      icon: Icons.local_gas_station,
    ),
  ];

  List<SensorModel> get sensors => List.unmodifiable(_sensors);

  void addSensor(SensorModel sensor) {
    _sensors.add(sensor);
    notifyListeners();
  }

  void updateSensorValue(String id, double value) {
    final sensor = _sensors.firstWhere(
      (s) => s.id == id,
      orElse: () => throw Exception('Sensor not found'),
    );
    sensor.value = value;
    sensor.history.add(value);
    notifyListeners();
  }

  Map<String, List<double>> get weeklyData {
    // Simulate weekly data for demo
    final Map<String, List<double>> data = {};
    for (final sensor in _sensors) {
      data[sensor.id] = List.generate(7, (i) => sensor.value + (i - 3) * 1.5);
    }
    return data;
  }

  double getWeeklyAverage(String sensorId) {
    final data = weeklyData[sensorId] ?? [];
    if (data.isEmpty) return 0.0;
    return data.reduce((a, b) => a + b) / data.length;
  }
}
