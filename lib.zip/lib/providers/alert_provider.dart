import 'package:flutter/material.dart';
import '../models/alert_model.dart';

class AlertProvider with ChangeNotifier {
  final Map<String, AlertModel> _alerts = {};

  Map<String, AlertModel> get alerts => _alerts;

  void setAlert(String sensorId, {double? min, double? max, String? whatsapp}) {
    _alerts[sensorId] = AlertModel(
      sensorId: sensorId,
      minThreshold: min,
      maxThreshold: max,
      whatsappNumber: whatsapp,
    );
    notifyListeners();
  }

  AlertModel? getAlert(String sensorId) => _alerts[sensorId];

  bool checkAlert(String sensorId, double value) {
    final alert = _alerts[sensorId];
    if (alert == null) return false;
    if (alert.minThreshold != null && value < alert.minThreshold!) return true;
    if (alert.maxThreshold != null && value > alert.maxThreshold!) return true;
    return false;
  }
}
