import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class UserProvider with ChangeNotifier {
  final _storage = FlutterSecureStorage();
  String _firstName = '';

  String get firstName => _firstName;

  UserProvider() {
    _loadName();
  }

  Future<void> _loadName() async {
    _firstName = await _storage.read(key: 'firstName') ?? '';
    notifyListeners();
  }

  Future<void> setFirstName(String name) async {
    _firstName = name;
    await _storage.write(key: 'firstName', value: name);
    notifyListeners();
  }
}
