import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/sensor_data.dart';
import '../services/mqtt_service.dart';

class AppState with ChangeNotifier {
  SensorData? _sensorData;
  String _connectionStatus = 'Disconnected';
  final MqttService mqttService;

  AppState(this.mqttService);

  SensorData? get sensorData => _sensorData;
  String get connectionStatus => _connectionStatus;

  Future<void> start() async {
    _connectionStatus = 'Connecting';
    notifyListeners();
    try {
      await mqttService.connect();
      mqttService.client?.updates?.listen((messages) {
        if (messages.isNotEmpty) {
          final message = messages[0].payload as dynamic;
          final payload = message is String ? message : message.toString();
          _sensorData = SensorData.fromJson(jsonDecode(payload));
          _connectionStatus = 'Connected';
          notifyListeners();
        }
      });
    } catch (e) {
      _connectionStatus = 'Disconnected';
      notifyListeners();
    }
  }

  void stop() {
    mqttService.disconnect();
    _connectionStatus = 'Disconnected';
    notifyListeners();
  }
}
