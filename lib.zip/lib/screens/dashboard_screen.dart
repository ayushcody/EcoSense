import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/sensor_provider.dart';
import '../models/sensor_model.dart';
import 'sensor_details_modal.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../providers/theme_provider.dart';
import '../providers/locale_provider.dart';
import '../providers/alert_provider.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../providers/user_provider.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final sensorProvider = Provider.of<SensorProvider>(context);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Row(
          children: [
            Icon(Icons.eco, color: Theme.of(context).iconTheme.color),
            SizedBox(width: 8),
            Text('EcoSense Dashboard'),
          ],
        ),
        actions: [
          _LanguageSwitcher(),
          _DarkModeToggle(),
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: () => Navigator.pushNamed(context, '/settings'),
          ),
        ],
      ),
      body: Stack(
        children: [
          // Nature SVGs
          Positioned(
            left: 0,
            top: 0,
            child: AnimatedOpacity(
              opacity: 1.0,
              duration: Duration(seconds: 2),
              child: SvgPicture.network(
                'https://www.svgrepo.com/show/331993/leaf.svg',
                width: 80,
                height: 80,
                color: Colors.green.withOpacity(0.3),
              ),
            ),
          ),
          Positioned(
            right: 0,
            bottom: 0,
            child: AnimatedOpacity(
              opacity: 1.0,
              duration: Duration(seconds: 2),
              child: SvgPicture.network(
                'https://www.svgrepo.com/show/331994/tree.svg',
                width: 120,
                height: 120,
                color: Colors.green.withOpacity(0.2),
              ),
            ),
          ),
          Positioned(
            left: 40,
            top: 60,
            child: AnimatedOpacity(
              opacity: 1.0,
              duration: Duration(seconds: 2),
              child: SvgPicture.network(
                'https://www.svgrepo.com/show/331995/cloud.svg',
                width: 90,
                height: 60,
                color: Colors.blueGrey.withOpacity(0.18),
              ),
            ),
          ),
          Positioned(
            right: 40,
            top: 120,
            child: AnimatedOpacity(
              opacity: 1.0,
              duration: Duration(seconds: 2),
              child: SvgPicture.network(
                'https://www.svgrepo.com/show/331996/butterfly.svg',
                width: 60,
                height: 60,
                color: Colors.deepPurple.withOpacity(0.18),
              ),
            ),
          ),
          Positioned(
            left: 0,
            bottom: 0,
            right: 0,
            child: AnimatedOpacity(
              opacity: 1.0,
              duration: Duration(seconds: 2),
              child: SvgPicture.network(
                'https://www.svgrepo.com/show/331997/grass.svg',
                width: 400,
                height: 60,
                color: Colors.green.withOpacity(0.15),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Positioned.fill(
            child: CachedNetworkImage(
              imageUrl:
                  'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
              fit: BoxFit.cover,
              alignment: Alignment.topCenter,
            ),
          ),
          Positioned.fill(
            child: Container(
              color: Theme.of(
                context,
              ).scaffoldBackgroundColor.withOpacity(0.85),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _WelcomeMessage(),
                Text(
                  'Sensor Dashboard',
                  style: Theme.of(
                    context,
                  ).textTheme.headlineMedium?.copyWith(fontSize: 32),
                ),
                SizedBox(height: 8),
                _WeatherSummaryCard(),
                SizedBox(height: 8),
                _WeeklyDataSummary(),
                SizedBox(height: 16),
                Expanded(
                  child: GridView.builder(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 24,
                      mainAxisSpacing: 24,
                      childAspectRatio: 1.3,
                    ),
                    itemCount: sensorProvider.sensors.length,
                    itemBuilder: (context, index) {
                      final sensor = sensorProvider.sensors[index];
                      return _SensorCard(sensor: sensor);
                    },
                  ),
                ),
                SizedBox(height: 16),
                _AlertSection(),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        heroTag: 'add_sensor',
        onPressed: () {
          _showAddSensorDialog(context);
        },
        child: Icon(Icons.add),
        tooltip: 'Add Sensor',
      ),
    );
  }

  void _showAddSensorDialog(BuildContext context) {
    final _nameController = TextEditingController();
    final _idController = TextEditingController();
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text('Add Sensor'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: _nameController,
                  decoration: InputDecoration(labelText: 'Sensor Name'),
                ),
                TextField(
                  controller: _idController,
                  decoration: InputDecoration(labelText: 'Sensor ID'),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () {
                  if (_nameController.text.isNotEmpty &&
                      _idController.text.isNotEmpty) {
                    Provider.of<SensorProvider>(
                      context,
                      listen: false,
                    ).addSensor(
                      SensorModel(
                        id: _idController.text,
                        name: _nameController.text,
                        type: 'custom',
                        unit: '',
                        icon: Icons.sensors,
                      ),
                    );
                    Navigator.pop(context);
                  }
                },
                child: Text('Add'),
              ),
            ],
          ),
    );
  }
}

class _SensorCard extends StatelessWidget {
  final SensorModel sensor;
  const _SensorCard({Key? key, required this.sensor}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 8,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          showDialog(
            context: context,
            builder: (context) => SensorDetailsModal(sensor: sensor),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    sensor.name,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  Icon(
                    sensor.icon,
                    color: Theme.of(context).iconTheme.color,
                    size: 28,
                  ),
                ],
              ),
              Text(
                sensor.value.toStringAsFixed(2) +
                    (sensor.unit.isNotEmpty ? ' ${sensor.unit}' : ''),
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              // TODO: Add status/description below value
            ],
          ),
        ),
      ),
    );
  }
}

class _WeatherSummaryCard extends StatelessWidget {
  const _WeatherSummaryCard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final sensorProvider = Provider.of<SensorProvider>(context);
    final temp =
        sensorProvider.sensors.firstWhere((s) => s.id == 'temperature').value;
    final hum =
        sensorProvider.sensors.firstWhere((s) => s.id == 'humidity').value;
    String weather = 'Sunny';
    IconData icon = Icons.wb_sunny;
    Color iconColor = Colors.orange;
    if (hum > 80) {
      weather = 'Rainy';
      icon = Icons.beach_access;
      iconColor = Colors.blueAccent;
    } else if (hum > 60) {
      weather = 'Cloudy';
      icon = Icons.cloud;
      iconColor = Colors.grey;
    } else if (temp > 35) {
      weather = 'Hot';
      icon = Icons.wb_sunny;
      iconColor = Colors.redAccent;
    }
    return Card(
      color: Colors.white.withOpacity(0.85),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Row(
          children: [
            Icon(icon, color: iconColor, size: 32),
            SizedBox(width: 12),
            Text(
              'Weather: $weather',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            Spacer(),
            Text(
              '${temp.toStringAsFixed(1)}°C',
              style: TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}

class _WeeklyDataSummary extends StatelessWidget {
  const _WeeklyDataSummary({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final sensorProvider = Provider.of<SensorProvider>(context);
    final tempAvg = sensorProvider
        .getWeeklyAverage('temperature')
        .toStringAsFixed(1);
    final humAvg = sensorProvider
        .getWeeklyAverage('humidity')
        .toStringAsFixed(1);
    final aqiAvg = sensorProvider
        .getWeeklyAverage('air_quality')
        .toStringAsFixed(0);
    final tempData = sensorProvider.weeklyData['temperature'] ?? [];
    return Row(
      children: [
        Icon(Icons.calendar_today, color: Theme.of(context).iconTheme.color),
        SizedBox(width: 8),
        Text('Weekly Avg: Temp $tempAvg°C, Humidity $humAvg%, AQI $aqiAvg'),
        SizedBox(width: 16),
        SizedBox(
          width: 60,
          height: 32,
          child:
              tempData.isNotEmpty
                  ? LineChart(
                    LineChartData(
                      gridData: FlGridData(show: false),
                      borderData: FlBorderData(show: false),
                      titlesData: FlTitlesData(show: false),
                      lineBarsData: [
                        LineChartBarData(
                          spots: [
                            for (int i = 0; i < tempData.length; i++)
                              FlSpot(i.toDouble(), tempData[i]),
                          ],
                          isCurved: true,
                          color: Colors.orange,
                          barWidth: 2,
                          dotData: FlDotData(show: false),
                        ),
                      ],
                    ),
                  )
                  : SizedBox.shrink(),
        ),
      ],
    );
  }
}

class _AlertSection extends StatelessWidget {
  const _AlertSection({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final alertProvider = Provider.of<AlertProvider>(context);
    final sensorProvider = Provider.of<SensorProvider>(context);
    // Check for any triggered alerts
    String? alertSensorId;
    String? whatsapp;
    double? value;
    for (final sensor in sensorProvider.sensors) {
      if (alertProvider.checkAlert(sensor.id, sensor.value)) {
        alertSensorId = sensor.id;
        whatsapp = alertProvider.getAlert(sensor.id)?.whatsappNumber;
        value = sensor.value;
        break;
      }
    }
    return Card(
      color: alertSensorId != null ? Colors.red[100] : Colors.red[50],
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: Row(
          children: [
            Icon(Icons.warning, color: Colors.red, size: 28),
            SizedBox(width: 12),
            Expanded(
              child:
                  alertSensorId != null
                      ? Text(
                        'Alert! ${alertSensorId.toUpperCase()} value $value crossed threshold.',
                      )
                      : Text('No alerts. Set thresholds to get notified!'),
            ),
            if (alertSensorId != null &&
                whatsapp != null &&
                whatsapp.isNotEmpty)
              TextButton.icon(
                icon: Icon(FontAwesomeIcons.whatsapp, color: Colors.green),
                label: Text('WhatsApp'),
                onPressed: () async {
                  final msg = Uri.encodeComponent(
                    'EcoSense Alert: $alertSensorId value $value crossed threshold!',
                  );
                  final url = 'https://wa.me/$whatsapp?text=$msg';
                  if (await canLaunchUrl(Uri.parse(url))) {
                    await launchUrl(
                      Uri.parse(url),
                      mode: LaunchMode.externalApplication,
                    );
                  }
                },
              ),
            TextButton(
              onPressed: () {
                _AlertSection.showThresholdDialog(context);
              },
              child: Text('Set Thresholds'),
            ),
          ],
        ),
      ),
    );
  }

  static void showThresholdDialog(BuildContext context) {
    final _sensorIdController = TextEditingController();
    final _minController = TextEditingController();
    final _maxController = TextEditingController();
    final _whatsappController = TextEditingController();
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text('Set Alert Thresholds'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: _sensorIdController,
                  decoration: InputDecoration(labelText: 'Sensor ID'),
                ),
                TextField(
                  controller: _minController,
                  decoration: InputDecoration(labelText: 'Min Value'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: _maxController,
                  decoration: InputDecoration(labelText: 'Max Value'),
                  keyboardType: TextInputType.number,
                ),
                TextField(
                  controller: _whatsappController,
                  decoration: InputDecoration(
                    labelText: 'WhatsApp Number (optional)',
                  ),
                  keyboardType: TextInputType.phone,
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () {
                  final sensorId = _sensorIdController.text;
                  final min = double.tryParse(_minController.text);
                  final max = double.tryParse(_maxController.text);
                  final whatsapp =
                      _whatsappController.text.isNotEmpty
                          ? _whatsappController.text
                          : null;
                  if (sensorId.isNotEmpty) {
                    Provider.of<AlertProvider>(context, listen: false).setAlert(
                      sensorId,
                      min: min,
                      max: max,
                      whatsapp: whatsapp,
                    );
                    Navigator.pop(context);
                  }
                },
                child: Text('Save'),
              ),
            ],
          ),
    );
  }
}

class _DarkModeToggle extends StatefulWidget {
  const _DarkModeToggle({Key? key}) : super(key: key);

  @override
  State<_DarkModeToggle> createState() => _DarkModeToggleState();
}

class _DarkModeToggleState extends State<_DarkModeToggle> {
  bool isDark = false;

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    isDark = themeProvider.themeMode == ThemeMode.dark;
    return IconButton(
      icon: AnimatedSwitcher(
        duration: Duration(milliseconds: 600),
        child:
            isDark
                ? Icon(
                  Icons.nightlight_round,
                  key: ValueKey('moon'),
                  color: Colors.amber,
                )
                : Icon(
                  Icons.wb_sunny,
                  key: ValueKey('sun'),
                  color: Colors.orange,
                ),
      ),
      tooltip: 'Toggle Dark Mode',
      onPressed: () {
        themeProvider.toggleTheme();
      },
    );
  }
}

class _LanguageSwitcher extends StatefulWidget {
  const _LanguageSwitcher({Key? key}) : super(key: key);

  @override
  State<_LanguageSwitcher> createState() => _LanguageSwitcherState();
}

class _LanguageSwitcherState extends State<_LanguageSwitcher> {
  String _selectedLang = 'en';
  final _langs = [
    {'code': 'en', 'label': 'EN'},
    {'code': 'hi', 'label': 'हिंदी'},
    {'code': 'mr', 'label': 'मराठी'},
  ];

  @override
  Widget build(BuildContext context) {
    return DropdownButtonHideUnderline(
      child: DropdownButton<String>(
        value: _selectedLang,
        icon: Icon(Icons.language, color: Theme.of(context).iconTheme.color),
        items:
            _langs
                .map(
                  (lang) => DropdownMenuItem(
                    value: lang['code'],
                    child: Text(lang['label']!),
                  ),
                )
                .toList(),
        onChanged: (val) {
          setState(() {
            _selectedLang = val!;
            final localeProvider = Provider.of<LocaleProvider>(
              context,
              listen: false,
            );
            localeProvider.setLocale(Locale(_selectedLang));
          });
        },
        style: TextStyle(color: Theme.of(context).iconTheme.color),
      ),
    );
  }
}

class _WelcomeMessage extends StatelessWidget {
  const _WelcomeMessage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final userProvider = Provider.of<UserProvider>(context);
    final String firstName =
        userProvider.firstName.isNotEmpty ? userProvider.firstName : 'User';
    return Row(
      children: [
        Text(
          'Welcome, $firstName!',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Theme.of(context).colorScheme.secondary,
          ),
        ),
        SizedBox(width: 8),
        IconButton(
          icon: Icon(
            Icons.account_circle,
            color: Theme.of(context).iconTheme.color,
          ),
          tooltip: 'Set Name',
          onPressed: () {
            _showNameDialog(context, userProvider);
          },
        ),
      ],
    );
  }

  void _showNameDialog(BuildContext context, UserProvider userProvider) {
    final _nameController = TextEditingController(text: userProvider.firstName);
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text('Enter your first name'),
            content: TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'First Name'),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Cancel'),
              ),
              ElevatedButton(
                onPressed: () {
                  if (_nameController.text.isNotEmpty) {
                    userProvider.setFirstName(_nameController.text);
                    Navigator.pop(context);
                  }
                },
                child: Text('Save'),
              ),
            ],
          ),
    );
  }
}
