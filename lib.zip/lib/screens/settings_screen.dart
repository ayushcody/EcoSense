import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/settings_provider.dart';

class SettingsScreen extends StatelessWidget {
  SettingsScreen({Key? key}) : super(key: key);
  final _endpointController = TextEditingController();
  final _accessKeyController = TextEditingController();
  final _secretKeyController = TextEditingController();
  final _regionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final settings = Provider.of<SettingsProvider>(context);
    _endpointController.text = settings.endpoint;
    _accessKeyController.text = settings.accessKey;
    _secretKeyController.text = settings.secretKey;
    _regionController.text = settings.region;

    return Scaffold(
      appBar: AppBar(title: Text('Settings')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _endpointController,
              decoration: InputDecoration(
                labelText:
                    'AWS IoT Endpoint (e.g., a1b2c3d4e5f6g7.iot.us-east-1.amazonaws.com)',
              ),
            ),
            TextField(
              controller: _accessKeyController,
              decoration: InputDecoration(labelText: 'AWS Access Key'),
            ),
            TextField(
              controller: _secretKeyController,
              decoration: InputDecoration(labelText: 'AWS Secret Key'),
              obscureText: true,
            ),
            TextField(
              controller: _regionController,
              decoration: InputDecoration(
                labelText: 'AWS Region (e.g., us-east-1)',
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                settings.saveSettings(
                  _endpointController.text,
                  _accessKeyController.text,
                  _secretKeyController.text,
                  _regionController.text,
                );
                ScaffoldMessenger.of(
                  context,
                ).showSnackBar(SnackBar(content: Text('Settings saved')));
              },
              child: Text('Save Settings'),
            ),
            if (settings.endpoint.isEmpty ||
                settings.accessKey.isEmpty ||
                settings.secretKey.isEmpty ||
                settings.region.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 24.0),
                child: Text(
                  'Enter your AWS IoT credentials to enable live sensor data.',
                  style: TextStyle(color: Colors.red),
                  textAlign: TextAlign.center,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
