import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/dashboard_screen.dart';
import 'screens/settings_screen.dart';
import 'providers/app_state.dart';
import 'providers/settings_provider.dart';
import 'providers/sensor_provider.dart';
import 'services/mqtt_service.dart';
import 'theme/ecosense_theme.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'providers/theme_provider.dart';
import 'providers/locale_provider.dart';
import 'providers/alert_provider.dart';
import 'providers/user_provider.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer2<ThemeProvider, LocaleProvider>(
      builder: (context, themeProvider, localeProvider, _) {
        return MaterialApp(
          title: 'EcoSense',
          theme: EcoSenseTheme.lightTheme,
          darkTheme: EcoSenseTheme.darkTheme,
          themeMode: themeProvider.themeMode,
          locale: localeProvider.locale,
          localizationsDelegates: [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: [Locale('en'), Locale('hi'), Locale('mr')],
          initialRoute: '/',
          routes: {
            '/': (context) => DashboardScreen(),
            '/settings': (context) => SettingsScreen(),
          },
        );
      },
    );
  }
}

void main() {
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => SettingsProvider()),
        ChangeNotifierProvider(create: (_) => SensorProvider()),
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
        ChangeNotifierProvider(create: (_) => LocaleProvider()),
        ChangeNotifierProvider(create: (_) => AlertProvider()),
        ChangeNotifierProvider(create: (_) => UserProvider()),
        ChangeNotifierProxyProvider<SettingsProvider, AppState>(
          create:
              (context) => AppState(
                MqttService(
                  settingsProvider: Provider.of<SettingsProvider>(
                    context,
                    listen: false,
                  ),
                ),
              ),
          update:
              (context, settingsProvider, previous) =>
                  AppState(MqttService(settingsProvider: settingsProvider)),
        ),
      ],
      child: MyApp(),
    ),
  );
}
