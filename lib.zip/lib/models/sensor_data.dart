class SensorData {
  final double temperature;
  final double humidity;
  final double airQuality;
  final DateTime timestamp;

  SensorData({
    required this.temperature,
    required this.humidity,
    required this.airQuality,
    required this.timestamp,
  });

  factory SensorData.fromJson(Map<String, dynamic> json) {
    return SensorData(
      temperature: (json['temperature'] as num?)?.toDouble() ?? 0.0,
      humidity: (json['humidity'] as num?)?.toDouble() ?? 0.0,
      airQuality: (json['air_quality'] as num?)?.toDouble() ?? 0.0,
      timestamp: DateTime.now(),
    );
  }
}
