class AlertModel {
  final String sensorId;
  double? minThreshold;
  double? maxThreshold;
  String? whatsappNumber;

  AlertModel({
    required this.sensorId,
    this.minThreshold,
    this.maxThreshold,
    this.whatsappNumber,
  });
}
