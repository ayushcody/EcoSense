import 'package:flutter/material.dart';

class SensorModel {
  final String id;
  final String name;
  final String type; // e.g., temperature, humidity, ph, gas, custom
  final String unit;
  final IconData icon;
  double value;
  List<double> history; // For graphing

  SensorModel({
    required this.id,
    required this.name,
    required this.type,
    required this.unit,
    required this.icon,
    this.value = 0.0,
    List<double>? history,
  }) : history = history ?? [];
}
