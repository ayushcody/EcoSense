import 'package:flutter/material.dart';

class EcoSenseTheme {
  static const Color antiqueWhite = Color(0xFFFAF3E3);
  static const Color ecoGreen = Color(0xFF6CBF84);
  static const Color accentBlue = Color(0xFF4FC3F7);
  static const Color cardShadow = Color(0x22000000);
  static const Color gardenBrown = Color(0xFFBCA177);
  static const Color leafGreen = Color(0xFFB7E4C7);
  static const Color skyBlue = Color(0xFFD0F4FF);

  static ThemeData lightTheme = ThemeData(
    brightness: Brightness.light,
    primaryColor: antiqueWhite,
    scaffoldBackgroundColor: antiqueWhite,
    cardColor: Colors.white,
    appBarTheme: AppBarTheme(
      backgroundColor: antiqueWhite,
      foregroundColor: ecoGreen,
      elevation: 0,
      iconTheme: IconThemeData(color: ecoGreen),
      titleTextStyle: TextStyle(
        color: ecoGreen,
        fontWeight: FontWeight.bold,
        fontSize: 22,
      ),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: ecoGreen,
      foregroundColor: Colors.white,
    ),
    cardTheme: CardTheme(
      color: Colors.white,
      shadowColor: cardShadow,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
    textTheme: TextTheme(
      headlineMedium: TextStyle(
        color: gardenBrown,
        fontWeight: FontWeight.bold,
      ),
      bodyLarge: TextStyle(color: ecoGreen),
      bodyMedium: TextStyle(color: gardenBrown),
    ),
    iconTheme: IconThemeData(color: ecoGreen),
  );

  static ThemeData darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: gardenBrown,
    scaffoldBackgroundColor: Color(0xFF232323),
    cardColor: Color(0xFF2C2C2C),
    appBarTheme: AppBarTheme(
      backgroundColor: gardenBrown,
      foregroundColor: antiqueWhite,
      elevation: 0,
      iconTheme: IconThemeData(color: leafGreen),
      titleTextStyle: TextStyle(
        color: antiqueWhite,
        fontWeight: FontWeight.bold,
        fontSize: 22,
      ),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: leafGreen,
      foregroundColor: Colors.black,
    ),
    cardTheme: CardTheme(
      color: Color(0xFF2C2C2C),
      shadowColor: cardShadow,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
    textTheme: TextTheme(
      headlineMedium: TextStyle(
        color: antiqueWhite,
        fontWeight: FontWeight.bold,
      ),
      bodyLarge: TextStyle(color: leafGreen),
      bodyMedium: TextStyle(color: antiqueWhite),
    ),
    iconTheme: IconThemeData(color: leafGreen),
  );
}
